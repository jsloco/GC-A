const desplegables = document.querySelectorAll('.opcion-con-desplegable');

let abierto = null;
let timeout = null;

desplegables.forEach(desplegable => {
    const oculto = desplegable.querySelector('.oculto');

    desplegable.addEventListener('mouseenter', () => {
        // Cierra el desplegable abierto si es otro
        if (abierto && abierto !== oculto) {
            abierto.style.display = 'none';
        }
        clearTimeout(timeout);
        oculto.style.display = 'block';
        abierto = oculto;
    });

    desplegable.addEventListener('mouseleave', () => {
        timeout = setTimeout(() => {
            oculto.style.display = 'none';
            if (abierto === oculto) {
                abierto = null;
            }
        }, 600);
    });

    oculto.addEventListener('mouseenter', () => {
        clearTimeout(timeout);
        oculto.style.display = 'block';
        abierto = oculto;
    });

    oculto.addEventListener('mouseleave', () => {
        timeout = setTimeout(() => {
            oculto.style.display = 'none';
            if (abierto === oculto) {
                abierto = null;
            }
        }, 600);
    });
});

// --- MENÚ MÓVIL SOLO PARA <=750px ---
(function() {
    const hamburguesa = document.querySelector('.hamburguesa');
    if (!hamburguesa) return;

    let menuMovil = document.querySelector('.menu-movil');
    if (!menuMovil) {
        menuMovil = document.createElement('div');
        menuMovil.className = 'menu-movil';
        document.body.appendChild(menuMovil);
    }

    function mostrarMenuMovil() {
        if (window.innerWidth <= 750) {
            menuMovil.classList.add('show');
        }
    }
    function ocultarMenuMovil() {
        menuMovil.classList.remove('show');
    }

    hamburguesa.addEventListener('click', function(e) {
        e.stopPropagation();
        if (menuMovil.classList.contains('show')) {
            ocultarMenuMovil();
        } else {
            mostrarMenuMovil();
        }
    });

    // Cierra el menú si haces click fuera
    document.addEventListener('click', function(e) {
        if (window.innerWidth > 750) return;
        if (!menuMovil.contains(e.target) && !hamburguesa.contains(e.target)) {
            ocultarMenuMovil();
        }
    });

    // Oculta el menú si cambias el tamaño de pantalla
    window.addEventListener('resize', function() {
        if (window.innerWidth > 750) ocultarMenuMovil();
    });
})();

const products = document.querySelectorAll(".products");
document.getElementById("year").textContent = new Date().getFullYear();